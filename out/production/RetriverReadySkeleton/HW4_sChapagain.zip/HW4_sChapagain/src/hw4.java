// Saurabh Chapagain
// Date: April 27, 2022.
// s205@umbc.edu


public class hw4 {

    public hw4(){
        //It will call a default constructor
        System.out.println("Default constructor");
    }

    public hw4(String stringArg){
        //It will call the constructor with String argument
        System.out.println("Parametrized constructor with String argument");
    }

    public hw4(String argument, int num3) {
        // It will call the constructor with (String, integer) arguments
        System.out.println("Parametrized constructor with (String, integer) arguments");
    }

    public hw4(int num1, int num2, int num3){
        //It will call the constructor with (int, int, int) arguments
        System.out.println("Parametrized constructor with three int arguments");
    }

}


